package ru.infinitedispenser;

import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.item.ItemStack;

/**
 * A copy of a dispenser's inventory taken right before it dispenses something.
 *
 * <p>Kept outside of the {@code ru.infinitedispenser.mixin} package on purpose: Mixin
 * forbids direct references to classes that live inside a mixin package.</p>
 */
public record DispenserSnapshot(DispenserBlockEntity dispenser, ItemStack[] contents) {
}
