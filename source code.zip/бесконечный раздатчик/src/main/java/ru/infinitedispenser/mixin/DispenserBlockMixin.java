package ru.infinitedispenser.mixin;

import java.util.ArrayDeque;
import java.util.Deque;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import ru.infinitedispenser.DispenserSnapshot;

/**
 * Makes regular dispensers never consume the items inside them.
 *
 * <p>Before every dispense the contents of the dispenser are copied. After the
 * dispense is finished the copied (non-empty) stacks are put back, so the
 * dispenser keeps throwing items forever.</p>
 */
@Mixin(DispenserBlock.class)
public class DispenserBlockMixin {

    @Unique
    private static final Deque<DispenserSnapshot> infiniteDispenser$snapshots = new ArrayDeque<>();

    @Inject(method = "dispense", at = @At("HEAD"))
    private void infiniteDispenser$captureContents(ServerWorld world, BlockState state, BlockPos pos, CallbackInfo ci) {
        // Only real dispensers are affected, droppers keep their vanilla behaviour.
        if (!state.isOf(Blocks.DISPENSER)) {
            infiniteDispenser$snapshots.push(new DispenserSnapshot(null, null));
            return;
        }

        DispenserBlockEntity dispenser = world.getBlockEntity(pos, BlockEntityType.DISPENSER).orElse(null);
        if (dispenser == null) {
            infiniteDispenser$snapshots.push(new DispenserSnapshot(null, null));
            return;
        }

        int size = dispenser.size();
        ItemStack[] contents = new ItemStack[size];
        for (int slot = 0; slot < size; slot++) {
            contents[slot] = dispenser.getStack(slot).copy();
        }
        infiniteDispenser$snapshots.push(new DispenserSnapshot(dispenser, contents));
    }

    @Inject(method = "dispense", at = @At("RETURN"))
    private void infiniteDispenser$restoreContents(ServerWorld world, BlockState state, BlockPos pos, CallbackInfo ci) {
        DispenserSnapshot snapshot = infiniteDispenser$snapshots.poll();
        if (snapshot == null || snapshot.dispenser() == null) {
            return;
        }

        DispenserBlockEntity dispenser = snapshot.dispenser();
        ItemStack[] contents = snapshot.contents();
        boolean changed = false;

        for (int slot = 0; slot < contents.length; slot++) {
            ItemStack original = contents[slot];
            if (original.isEmpty()) {
                continue;
            }

            ItemStack current = dispenser.getStack(slot);
            if (!ItemStack.areItemsAndComponentsEqual(current, original) || current.getCount() != original.getCount()) {
                dispenser.setStack(slot, original.copy());
                changed = true;
            }
        }

        if (changed) {
            dispenser.markDirty();
        }
    }
}
